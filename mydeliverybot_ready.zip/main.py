import os
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("שלום! הבוט פעיל ומוכן לקבל מידע.")

app = ApplicationBuilder().token("7304089168:AAE8ct92OXmo8MWUDbeZ-8GPEO2vkiUrzZM").build()
app.add_handler(CommandHandler("start", start))
app.run_polling()
